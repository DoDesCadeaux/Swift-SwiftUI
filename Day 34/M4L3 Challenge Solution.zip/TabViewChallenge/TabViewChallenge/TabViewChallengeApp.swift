//
//  TabViewChallengeApp.swift
//  TabViewChallenge
//
//  Created by Micah Beech on 2021-02-15.
//

import SwiftUI

@main
struct TabViewChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
