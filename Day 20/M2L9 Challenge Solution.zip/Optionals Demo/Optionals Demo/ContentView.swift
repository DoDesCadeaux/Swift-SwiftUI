//
//  ContentView.swift
//  Optionals Demo
//
//  Created by Christopher Ching on 2021-01-19.
//

import SwiftUI

struct ContentView: View {
    @State var array:[String]?
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button("Clear") {
                    
                    // Set the array to nil
                    array = nil
                }
                Button("Add") {
                    
                    // We won't be able to add strings to nil, so we have to create a new array instance first
                    array = [String]()
                    
                    // Add two strings to the array
                    array?.append("Cheese")
                    array?.append("Milk")
                    
                    // Better yet, you can also reduce the above 3 lines of code into 1:
                    // array = ["Cheese", "Milk"]
                }
            }
            
            // Conditionally display UI elements
            if array == nil {
                Text("Please click the add button")
            }
            else {
                // Since we already checked that array is not nil,
                // I can safely force unwrap it here without fear of getting nil
                List(array!, id: \.self) { item in
                    Text(item)
                }
            }
            
        }
        
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
