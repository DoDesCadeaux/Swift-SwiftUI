//
//  Optionals_DemoApp.swift
//  Optionals Demo
//
//  Created by Christopher Ching on 2021-01-19.
//

import SwiftUI

@main
struct Optionals_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
