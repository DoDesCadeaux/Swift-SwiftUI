//
//  RecipeModel.swift
//  mvvm-demo
//
//  Created by Christopher Ching on 2021-01-07.
//

import Foundation

class RecipeModel: ObservableObject {
    
    @Published var recipes = [Recipe]()
    
    init() {
        
        // Create some dummy recipe data
        recipes.append(Recipe(name: "Spaghetti", cuisine: "Italian"))
        
        recipes.append(Recipe(name: "Sushi", cuisine: "Japanese"))
    }
    
    func addRecipe() {
        
        recipes.append(Recipe(name: "Burger", cuisine: "American"))
    }
}
