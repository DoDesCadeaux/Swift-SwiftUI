//
//  ChallengeApp.swift
//  Challenge
//
//  Created by Christopher Ching on 2021-01-15.
//

import SwiftUI

@main
struct ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
