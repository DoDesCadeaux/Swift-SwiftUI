let names = ["Sally", "Sheldon", "Claire", "Miranda", "Steve"]

class Person {
    var name = ""
    
    func introduceMyself() {
        print ("Hi, my name is \(name).")
    }
}

class Chef: Person {
    override func introduceMyself() {
        super.introduceMyself()
        print("I'm a chef.")
    }
}

class Barber: Person {
    override func introduceMyself() {
        super.introduceMyself()
        print("I'm a barber.")
    }
}

class Clown: Person {
    override func introduceMyself() {
        super.introduceMyself()
        print("I'm a clown.")
    }
}

// Loop 10 times
for _ in 1...10 {
    
    // Randomize a number for the name
    
    // I put it all in one line of code but you can definitely split it up into two lines of code like this:
    // let randomIndex = Int.random(in: 0...names.count-1)
    // let randomName = names[randomIndex]
    let randomName = names[Int.random(in: 0...names.count-1)]
    
    // Randomize an int between 1 to 3 for selecting the subclass
    let randomNumber = Int.random(in: 1...3)
    
    // Declare a person variable with a new Person object.
    var person = Person()
    
    // You can use a switch statement too if you've learned that. Otherwise, we'll learn about switch statements later. For now use a branching If statement.
    if randomNumber == 1 {
        
        // We can assign a Chef object to a variable that accepts the Person data type! This is because Chef is a subclass of Person
        person = Chef()
    }
    else if randomNumber == 2 {
        
        // Same thing here. Even though person is a Person Data Type variable, we can assign a Barber object to it
        person = Barber()
    }
    else if randomNumber == 3 {
        
        // Surprise, surprise! We can assign Clown objects to the Person variable too.
        person = Clown()
    }
    
    // Assign name
    person.name = randomName
    
    // Now when we call this method, it doesn't matter what type this variable references because they are all subclasses of the Person class and they all have the introduceMyself method.
    // Depending on what data type is actually referenced by this variable, you'll get the corresponding print output from this method call.
    person.introduceMyself()
}
