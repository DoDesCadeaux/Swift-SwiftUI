
class Person {
    
    var name = ""
    
    func talk() {
        print("Make conversation")
    }
}

var a = Person()

// Subclassing
class Comedian: Person {
    
}

var c = Comedian()
c.talk()

