//
//  ContentView.swift
//  LazyVStackChallenge
//
//  Created by Micah Beech on 2021-03-01.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading) {
                ForEach(0..<60) { index in
                    
                    Rectangle()
                        .fill(RadialGradient(
                            gradient: Gradient(colors: [.orange, .red]),
                            center: UnitPoint(x: 0.5, y: 0.5),
                            startRadius: 0,
                            endRadius: 200
                        ))
                        .frame(height: pow(1.1, CGFloat(index)))
                        .cornerRadius(10)
                    
                }
            }
            .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
