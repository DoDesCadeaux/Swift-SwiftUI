//
//  LazyVStackChallengeApp.swift
//  LazyVStackChallenge
//
//  Created by Micah Beech on 2021-03-01.
//

import SwiftUI

@main
struct LazyVStackChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
