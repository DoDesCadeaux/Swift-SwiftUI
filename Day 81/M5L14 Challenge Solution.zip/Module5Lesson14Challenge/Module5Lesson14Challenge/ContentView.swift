//
//  ContentView.swift
//  Module5Lesson14Challenge
//
//  Created by Micah Beech on 2021-04-27.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var model: Model
    
    var body: some View {
        VStack {
            Text(model.fact)
                .padding()
            
            Button("Get a new fact!") {
                model.getFact()
            }
            .padding()
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(model: Model())
    }
}
