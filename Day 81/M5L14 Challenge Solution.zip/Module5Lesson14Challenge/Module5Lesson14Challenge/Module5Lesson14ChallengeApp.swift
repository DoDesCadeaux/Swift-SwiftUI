//
//  Module5Lesson14ChallengeApp.swift
//  Module5Lesson14Challenge
//
//  Created by Micah Beech on 2021-04-27.
//

import SwiftUI

@main
struct Module5Lesson14ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(model: Model())
        }
    }
}
