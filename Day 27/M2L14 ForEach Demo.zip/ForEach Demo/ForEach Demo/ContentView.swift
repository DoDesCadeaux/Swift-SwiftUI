//
//  ContentView.swift
//  ForEach Demo
//
//  Created by Christopher Ching on 2021-01-14.
//

import SwiftUI

struct ContentView: View {
    
    var array = ["Pizza", "Burrito", "Sushi"]
    
    var body: some View {
        
        ScrollView {
            ForEach (array, id: \.self) { r in
                
                // This code will be repeated for each element in the array
                Text(r)
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
