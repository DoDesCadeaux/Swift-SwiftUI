//
//  ForEach_DemoApp.swift
//  ForEach Demo
//
//  Created by Christopher Ching on 2021-01-14.
//

import SwiftUI

@main
struct ForEach_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
