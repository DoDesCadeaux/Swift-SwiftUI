//
//  M2L3_List_ChallengeApp.swift
//  M2L3 List Challenge
//
//  Created by Christopher Ching on 2020-12-23.
//

import SwiftUI

@main
struct M2L3_List_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
