//
//  List_DemoApp.swift
//  List Demo
//
//  Created by Christopher Ching on 2020-12-22.
//

import SwiftUI

@main
struct List_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
