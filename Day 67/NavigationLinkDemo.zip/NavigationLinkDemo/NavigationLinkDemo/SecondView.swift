//
//  SecondView.swift
//  NavigationLinkDemo
//
//  Created by Christopher Ching on 2021-03-24.
//

import SwiftUI

struct SecondView: View {
    
    @Binding var selectedIndex:Int?
    
    var body: some View {
        VStack {
            Text("Hello, World!")
            Button("Navigate Back") {
                selectedIndex = nil
            }
        }
    }
}

