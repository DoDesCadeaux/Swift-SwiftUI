//
//  NavigationLinkDemoApp.swift
//  NavigationLinkDemo
//
//  Created by Christopher Ching on 2021-03-24.
//

import SwiftUI

@main
struct NavigationLinkDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
