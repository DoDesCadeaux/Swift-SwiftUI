//
//  PickerControlChallengeApp.swift
//  PickerControlChallenge
//
//  Created by Micah Beech on 2021-03-01.
//

import SwiftUI

@main
struct PickerControlChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
