var myNum = 10
var myArray = [10, 100, 1000]

myArray[0] = 1

myArray.remove(at: 1)

print(myArray)
