//
//  M2L2_ChallengeApp.swift
//  M2L2 Challenge
//
//  Created by Christopher Ching on 2020-12-23.
//

import SwiftUI

@main
struct M2L2_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
