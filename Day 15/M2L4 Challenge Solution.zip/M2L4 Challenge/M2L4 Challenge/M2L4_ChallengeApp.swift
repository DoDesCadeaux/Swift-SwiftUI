//
//  M2L4_ChallengeApp.swift
//  M2L4 Challenge
//
//  Created by Christopher Ching on 2020-12-24.
//

import SwiftUI

@main
struct M2L4_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
