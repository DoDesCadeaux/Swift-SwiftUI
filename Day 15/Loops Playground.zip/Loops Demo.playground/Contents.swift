var array = [1, 5, 10]

// For - In
/*
for index in 0...array.count-1 {

    print(array[index])
}
*/
/*
for element in array {
    print(element)
}
*/


var counter = 10

// Repeat While

repeat {
    print(counter)
    counter -= 1
    
} while counter > 0


// While

while counter > 0 {
    
    print(counter)
    counter -= 1
}

