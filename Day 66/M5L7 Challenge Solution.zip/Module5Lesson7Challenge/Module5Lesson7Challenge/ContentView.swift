//
//  ContentView.swift
//  Module5Lesson7Challenge
//
//  Created by Micah Beech on 2021-04-26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        WebView(url: URL(string: "https://codewithchris.com")!)
            .edgesIgnoringSafeArea(.bottom)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
