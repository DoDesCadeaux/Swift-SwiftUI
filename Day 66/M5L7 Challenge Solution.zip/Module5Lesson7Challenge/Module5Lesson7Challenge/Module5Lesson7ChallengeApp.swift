//
//  Module5Lesson7ChallengeApp.swift
//  Module5Lesson7Challenge
//
//  Created by Micah Beech on 2021-04-26.
//

import SwiftUI

@main
struct Module5Lesson7ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
