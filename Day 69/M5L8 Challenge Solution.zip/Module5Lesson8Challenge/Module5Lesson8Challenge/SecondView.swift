//
//  SecondView.swift
//  Module5Lesson8Challenge
//
//  Created by Micah Beech on 2021-04-26.
//

import SwiftUI

struct SecondView: View {
    
    @Binding var selectedView: Int?
    
    var body: some View {
        VStack {
            Text("I am view \(selectedView ?? 0)")
                .font(.largeTitle)
            
            Button("Go back") {
                selectedView = nil
            }
            .padding()
        }
        .navigationBarHidden(true)
        .padding()
    }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView(selectedView: .constant(1))
    }
}
