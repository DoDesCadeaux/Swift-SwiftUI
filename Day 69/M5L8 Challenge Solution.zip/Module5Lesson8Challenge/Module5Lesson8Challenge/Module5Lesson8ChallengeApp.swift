//
//  Module5Lesson8ChallengeApp.swift
//  Module5Lesson8Challenge
//
//  Created by Micah Beech on 2021-04-26.
//

import SwiftUI

@main
struct Module5Lesson8ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
