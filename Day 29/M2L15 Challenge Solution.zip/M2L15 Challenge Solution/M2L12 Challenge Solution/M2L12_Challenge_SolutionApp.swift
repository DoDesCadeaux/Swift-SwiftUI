//
//  M2L12_Challenge_SolutionApp.swift
//  M2L12 Challenge Solution
//
//  Created by Christopher Ching on 2021-01-19.
//

import SwiftUI

@main
struct M2L12_Challenge_SolutionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
