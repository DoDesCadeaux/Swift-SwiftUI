//
//  FeaturedViewChallengeApp.swift
//  FeaturedViewChallenge
//
//  Created by Micah Beech on 2021-02-28.
//

import SwiftUI

@main
struct FeaturedViewChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
