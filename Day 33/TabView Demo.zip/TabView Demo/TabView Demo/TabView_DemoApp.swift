//
//  TabView_DemoApp.swift
//  TabView Demo
//
//  Created by Christopher Ching on 2021-02-03.
//

import SwiftUI

@main
struct TabView_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
