//
//  M2L16_Challenge_SolutionApp.swift
//  M2L16 Challenge Solution
//
//  Created by Christopher Ching on 2021-02-04.
//

import SwiftUI

@main
struct M2L16_Challenge_SolutionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
