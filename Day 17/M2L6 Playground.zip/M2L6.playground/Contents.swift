// Class
class Person {
    
    var name = ""
    
    func talk() {
        print("Make conversation")
    }
}

// Subclassing
class Comedian: Person {
    
    override func talk() {
        print("Make people laugh")
        
        super.talk()
    }
}

// Struct
struct TalkShowHost {
    var name = ""
}

// Test function
func changeName(p:Comedian) {
    p.name = "Shane"
}

// Structures are value types
// Classes are reference types

var a = Comedian()
a.name = "Chris"

var b = a
b.name = "David"

changeName(p: a)

print(a.name)
print(b.name)
