//
//  Recipe.swift
//  mvvm-demo
//
//  Created by Christopher Ching on 2021-01-07.
//

import Foundation

class Recipe: Identifiable, Decodable {
    
    var id:UUID?
    var name = ""
    var cuisine = ""
    
}
