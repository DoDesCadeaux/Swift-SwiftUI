//
//  GeometryReader_DemoApp.swift
//  GeometryReader Demo
//
//  Created by Christopher Ching on 2021-02-05.
//

import SwiftUI

@main
struct GeometryReader_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
