//
//  GeometryReaderChallengeApp.swift
//  GeometryReaderChallenge
//
//  Created by Micah Beech on 2021-02-17.
//

import SwiftUI

@main
struct GeometryReaderChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
