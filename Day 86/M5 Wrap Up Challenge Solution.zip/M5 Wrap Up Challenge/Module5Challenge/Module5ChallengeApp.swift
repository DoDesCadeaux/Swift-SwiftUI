//
//  Module5ChallengeApp.swift
//  Module5Challenge
//
//  Created by Micah Beech on 2021-04-27.
//

import SwiftUI

@main
struct Module5ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            SearchView(model: SearchViewModel())
        }
    }
}
