//
//  Video.swift
//  Module5Challenge
//
//  Created by Micah Beech on 2021-05-22.
//

import Foundation

struct Video: Decodable, Identifiable {
    var id: Int
    var title: String
    var url: String
}
