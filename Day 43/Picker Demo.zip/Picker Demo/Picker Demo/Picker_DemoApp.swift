//
//  Picker_DemoApp.swift
//  Picker Demo
//
//  Created by Christopher Ching on 2021-02-10.
//

import SwiftUI

@main
struct Picker_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
